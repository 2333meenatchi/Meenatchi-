n=int(input("Enter input number:"))
fact=1
if n < 0:
  print("factorial does not exist for neg")
elif n==0:
  print("The factorial of 0 is 1")
else:
  for i in range(1,n+1):
      fact = fact * i
  print ("The factorial of",n,"is",fact)
